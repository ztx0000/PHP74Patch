# PHP-FPM 7.4.33 Dedicated Security Patch Guide

This standalone patch updates the **CLI binary toolchain** and the **PHP-FPM service manager** to fix critical security vulnerabilities while ensuring 100% compatibility with your existing Remi NTS extensions.

## 1. Upgrade Commands
```bash
cd /tmp && tar -zxvf php74-remi-fpm-only-patch.tar.gz && cd php74-remi-fpm-only-patch/
sudo ./install_fpm_patch.sh
```

## 2. Emergency Rollback (Under 5 Seconds)
If you encounter any unexpected application regression, run the following commands to instantly revert back to the pristine Remi official binaries:
```bash
[ -f /opt/remi/php74/root/usr/bin/php.remi.bak ] && mv -f /opt/remi/php74/root/usr/bin/php.remi.bak /opt/remi/php74/root/usr/bin/php
[ -f /opt/remi/php74/root/usr/sbin/php-fpm.remi.bak ] && mv -f /opt/remi/php74/root/usr/sbin/php-fpm.remi.bak /opt/remi/php74/root/usr/sbin/php-fpm
systemctl daemon-reload
systemctl restart php74-php-fpm
echo "[✓] Successfully rolled back to standard Remi repository packages."
```
