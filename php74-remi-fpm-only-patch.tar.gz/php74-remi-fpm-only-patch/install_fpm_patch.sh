#!/bin/bash
set -e

echo "======================================================"
echo " 开始应用 PHP-FPM 7.4.33 独立安全补丁 (Remi 无损替换版)"
echo "======================================================"

# 1. 安全备份目标机上的原 Remi 二进制组件 (仅当备份不存在时执行)
[ -f /opt/remi/php74/root/usr/bin/php ] && [ ! -f /opt/remi/php74/root/usr/bin/php.remi.bak ] && cp /opt/remi/php74/root/usr/bin/php /opt/remi/php74/root/usr/bin/php.remi.bak
[ -f /opt/remi/php74/root/usr/sbin/php-fpm ] && [ ! -f /opt/remi/php74/root/usr/sbin/php-fpm.remi.bak ] && cp /opt/remi/php74/root/usr/sbin/php-fpm /opt/remi/php74/root/usr/sbin/php-fpm.remi.bak

# 2. 同步目标机上的隔离版 OpenSSL 依赖环境
echo "--> 同步 OpenSSL 1.1.1w 运行库支撑..."
mkdir -p /opt
cp -a openssl11 /opt/

# 3. 覆盖替换核心二进制工具链与 FPM 主程序
echo "--> 覆盖替换核心二进制文件 (NTS 架构)..."
cp -a root_dir/bin/* /opt/remi/php74/root/usr/bin/
cp -a root_dir/sbin/* /opt/remi/php74/root/usr/sbin/

# 4. 规避、对齐 NTS 动态链条扩展目录，建立软链接兼容
echo "--> 对齐并挂载 NTS 动态链接库扩展..."
mkdir -p /opt/remi/php74/root/usr/lib64/extensions/no-debug-non-zts-20190902/
cp -a extensions/* /opt/remi/php74/root/usr/lib64/extensions/no-debug-non-zts-20190902/ 2>/dev/null || true
cp -a /opt/remi/php74/root/usr/lib64/php/modules/*.so /opt/remi/php74/root/usr/lib64/extensions/no-debug-non-zts-20190902/ 2>/dev/null || true

# 5. 重新载入 Systemd 守护进程并平滑重启服务
echo "--> 正在平滑重启 php74-php-fpm 服务..."
systemctl daemon-reload
if systemctl is-active php74-php-fpm &>/dev/null || systemctl is-enabled php74-php-fpm &>/dev/null; then
    systemctl restart php74-php-fpm
    echo "======================================================"
    echo " 🎉 独立版 PHP-FPM 补丁升级成功！"
    echo " 请执行 /opt/remi/php74/root/usr/bin/php -v 检查扩展是否正常"
    echo "======================================================"
else
    echo "--> [提示] 目标服务器当前未激活 php74-php-fpm 服务，已完成静默替换。"
    echo "    后续如需使用，可直接执行: systemctl enable --now php74-php-fpm"
fi
