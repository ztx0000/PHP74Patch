#!/bin/bash
set -e

echo "======================================================"
echo " 开始应用自编译 PHP 7.4.33 安全漏洞补丁 (Remi 无损替换版)"
echo "======================================================"

# 1. 安全备份原 Remi 的文件 (仅当备份不存在时执行)
[ -f /opt/remi/php74/root/usr/bin/php ] && [ ! -f /opt/remi/php74/root/usr/bin/php.remi.bak ] && cp /opt/remi/php74/root/usr/bin/php /opt/remi/php74/root/usr/bin/php.remi.bak
[ -f /usr/lib64/httpd/modules/libphp74.so ] && [ ! -f /usr/lib64/httpd/modules/libphp74.so.bak ] && cp /usr/lib64/httpd/modules/libphp74.so /usr/lib64/httpd/modules/libphp74.so.bak

# 2. 同步隔离版 OpenSSL 环境
echo "--> 同步 OpenSSL 1.1.1w 隔离依赖环境..."
mkdir -p /opt
cp -a openssl11 /opt/

# 3. 覆盖核心二进制工具链
echo "--> 替换 Remi PHP 核心二进制文件..."
cp -a root_dir/* /opt/remi/php74/root/usr/bin/

# 4. 补齐可能缺失的 NTS 核心扩展
echo "--> 补齐扩展支持..."
mkdir -p /opt/remi/php74/root/usr/lib64/extensions/no-debug-non-zts-20190902/
cp -a extensions/* /opt/remi/php74/root/usr/lib64/extensions/no-debug-non-zts-20190902/ 2>/dev/null || true
# 联动原 Remi 系统的软链接兼容
cp -a /opt/remi/php74/root/usr/lib64/php/modules/*.so /opt/remi/php74/root/usr/lib64/extensions/no-debug-non-zts-20190902/ 2>/dev/null || true

# 5. 替换 Apache 的 libphp74.so 模块
if [ -d /usr/lib64/httpd/modules ]; then
    echo "--> 替换补丁版 Apache 模块..."
    cp -a apache_mod/libphp74.so /usr/lib64/httpd/modules/libphp74.so
    
    # 修复 SELinux 上下文，防止系统自带 Apache 启动阻断
    if command -v restorecon &> /dev/null; then
        restorecon -v /usr/lib64/httpd/modules/libphp74.so
    fi
fi

# 6. 重启服务
echo "--> 重启 httpd 服务..."
if httpd -t &>/dev/null; then
    systemctl restart httpd
    echo "======================================================"
    echo " 🎉 补丁包替换并安装成功！"
    echo " 请执行 /opt/remi/php74/root/usr/bin/php -v 验证"
    echo "======================================================"
else
    echo "[X] 错误: Apache 语法检查失败，请手动检查配置文件！"
fi
